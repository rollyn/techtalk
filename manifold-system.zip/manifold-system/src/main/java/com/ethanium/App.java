package com.ethanium;

import manifold.ext.rt.api.Jailbreak;
import manifold.science.measures.Mass;

import java.time.LocalDate;

import static manifold.science.util.UnitConstants.kg;

public class App {

    public static void main(String[] args) throws Exception {

        String fileSystem = "s3";

        System.out.println( fileSystem.isS3());
        
        Mass m = 5 kg * 2.2 ;

        System.out.println( m.getValue().intValue() );


        Person p = new Person();
        p.title = "Mr";
        p.name = "Rollyn";
        System.out.println( p.title + " " + p.name );

        @Jailbreak Account account = new Account();
        account.compute();

        String petType = "Dog";
        Pet pet = Pet.create(petType);
        System.out.println( pet.say() );


    }
}
