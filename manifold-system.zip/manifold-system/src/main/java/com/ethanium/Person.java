package com.ethanium;

import manifold.ext.props.rt.api.var;

public class Person {

    @var
    String title;
    @var String name;
}
