package com.ethanium;

import manifold.internal.runtime.Bootstrap;

public interface Pet {
    String say();

    static Pet create(String type) throws Exception {

        String petType = type.equals("Dog") ? "darkj.Dog" : "darkj.Cat";
        return (Pet) Class.forName(petType).newInstance();
    }
}
