package com.ethanium.extensions.java.lang.String;

import manifold.ext.rt.api.Extension;
import manifold.ext.rt.api.This;

@Extension
public class FileSystem {

    public static boolean isS3(@This String item) {
        return item.equalsIgnoreCase("S3");
    }
}
