package com.ethanium;

public class Account {

    private void compute() {
        System.out.println("Compute");
    }
}
