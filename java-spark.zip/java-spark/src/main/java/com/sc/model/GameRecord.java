package com.sc.model;

import java.io.Serializable;
import java.time.LocalDateTime;

public class GameRecord implements Serializable {
    private String id;
    private boolean rated;
    private String createdAt;
    private String lastMoveAt;
    private int turns;
    private String victoryStatus;
    private String winner;
    private String incrementCode;
    private String whiteId;
    private int whiteRating;
    private String blackId;
    private int blackRating;
    private String moves;
    private String openingEco;
    private String openingName;
    private int openingPly;

    public GameRecord() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public boolean isRated() { return rated; }
    public void setRated(boolean rated) { this.rated = rated; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

    public String getLastMoveAt() { return lastMoveAt; }
    public void setLastMoveAt(String lastMoveAt) { this.lastMoveAt = lastMoveAt; }

    public int getTurns() { return turns; }
    public void setTurns(int turns) { this.turns = turns; }

    public String getVictoryStatus() { return victoryStatus; }
    public void setVictoryStatus(String victoryStatus) { this.victoryStatus = victoryStatus; }

    public String getWinner() { return winner; }
    public void setWinner(String winner) { this.winner = winner; }

    public String getIncrementCode() { return incrementCode; }
    public void setIncrementCode(String incrementCode) { this.incrementCode = incrementCode; }

    public String getWhiteId() { return whiteId; }
    public void setWhiteId(String whiteId) { this.whiteId = whiteId; }

    public int getWhiteRating() { return whiteRating; }
    public void setWhiteRating(int whiteRating) { this.whiteRating = whiteRating; }

    public String getBlackId() { return blackId; }
    public void setBlackId(String blackId) { this.blackId = blackId; }

    public int getBlackRating() { return blackRating; }
    public void setBlackRating(int blackRating) { this.blackRating = blackRating; }

    public String getMoves() { return moves; }
    public void setMoves(String moves) { this.moves = moves; }

    public String getOpeningEco() { return openingEco; }
    public void setOpeningEco(String openingEco) { this.openingEco = openingEco; }

    public String getOpeningName() { return openingName; }
    public void setOpeningName(String openingName) { this.openingName = openingName; }

    public int getOpeningPly() { return openingPly; }
    public void setOpeningPly(int openingPly) { this.openingPly = openingPly; }

    @Override
    public String toString() {
        return "GameRecord{" +
                "id='" + id + '\'' +
                ", rated=" + rated +
                ", createdAt='" + createdAt + '\'' +
                ", lastMoveAt='" + lastMoveAt + '\'' +
                ", turns=" + turns +
                ", victoryStatus='" + victoryStatus + '\'' +
                ", winner='" + winner + '\'' +
                ", incrementCode='" + incrementCode + '\'' +
                ", whiteId='" + whiteId + '\'' +
                ", whiteRating=" + whiteRating +
                ", blackId='" + blackId + '\'' +
                ", blackRating=" + blackRating +
                ", moves='" + moves + '\'' +
                ", openingEco='" + openingEco + '\'' +
                ", openingName='" + openingName + '\'' +
                ", openingPly=" + openingPly +
                '}';
    }
}
