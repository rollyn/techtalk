package com.sc.service;

import com.sc.model.GameRecord;
import java.io.File;
import java.io.IOException;
import java.util.List;
import org.apache.spark.sql.*;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

@Service
public class JavaSparkService {

  private final SparkSession sparkSession;

  private Dataset<Row> rows;
  public JavaSparkService(SparkSession sparkSession) {
    this.sparkSession = sparkSession;
    rows = loadCsv();
  }

  public Dataset<Row> loadCsv() {
    try {
      File resourceFile = new ClassPathResource("games.csv").getFile();
      String absolutePath = resourceFile.getAbsolutePath();

      Dataset<Row> dataset =
          sparkSession
              .read()
              .option("header", "true")
              .option("inferSchema", "true")
              .csv(absolutePath);

      return dataset
          .withColumnRenamed("id", "id")
          .withColumnRenamed("rated", "rated")
          .withColumnRenamed("created_at", "createdAt")
          .withColumnRenamed("last_move_at", "lastMoveAt")
          .withColumnRenamed("turns", "turns")
          .withColumnRenamed("victory_status", "victoryStatus")
          .withColumnRenamed("winner", "winner")
          .withColumnRenamed("increment_code", "incrementCode")
          .withColumnRenamed("white_id", "whiteId")
          .withColumnRenamed("white_rating", "whiteRating")
          .withColumnRenamed("black_id", "blackId")
          .withColumnRenamed("black_rating", "blackRating")
          .withColumnRenamed("moves", "moves")
          .withColumnRenamed("opening_eco", "openingEco")
          .withColumnRenamed("opening_name", "openingName")
          .withColumnRenamed("opening_ply", "openingPly");

    } catch (IOException e) {
      throw new RuntimeException("Error loading CSV file from resources", e);
    }
  }

  public List<GameRecord> getGameRecords() {

    Dataset<Row> dataset = rows;

    Dataset<GameRecord> gameDataset = dataset.as(Encoders.bean(GameRecord.class));

    return gameDataset.collectAsList().subList(0, 5);
  }

  public List<GameRecord> getWinnerBy(String color) {

    Dataset<Row> dataset = rows;

    Dataset<GameRecord> gameDataset = dataset.as(Encoders.bean(GameRecord.class))
            .filter(functions.col("winner").equalTo(color));

    return gameDataset.collectAsList().subList(0, 5);
  }
}
