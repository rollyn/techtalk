package com.sc.config;

import java.io.File;
import org.apache.spark.sql.SparkSession;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SparkConfig {

  static {
    File hadoopTempDir = new File("c:/hadoop");
    if (!hadoopTempDir.exists()) {
      hadoopTempDir.mkdirs();
    }
    System.setProperty("hadoop.home.dir", hadoopTempDir.getAbsolutePath());
  }

  @Bean
  public SparkSession sparkSession() {
    return SparkSession.builder()
        .appName("java-spark")
        .master("local[*]")
        .config("spark.ui.enabled", "false")
        .config("spark.files.ignoreMissingFiles", "true")
        .config("spark.sql.files.ignoreCorruptFiles", "true")
        .getOrCreate();
  }
}
