package com.sc.controller;

import com.sc.model.GameRecord;
import com.sc.service.JavaSparkService;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JavaSparkController {

  private final JavaSparkService javaSparkService;

  public JavaSparkController(JavaSparkService javaSparkService) {
    this.javaSparkService = javaSparkService;
  }

  @GetMapping
  public List<GameRecord> show() {

    return javaSparkService.getGameRecords();
  }

  @GetMapping("/winner/{color}")
  public List<GameRecord> geWinner(@PathVariable String color) {

    return javaSparkService.getWinnerBy(color);
  }
}
