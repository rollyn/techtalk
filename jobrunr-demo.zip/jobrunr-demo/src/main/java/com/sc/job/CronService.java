package com.sc.job;

import org.jobrunr.scheduling.JobScheduler;
import org.springframework.stereotype.Service;

@Service
public class CronService {

    private final JobScheduler jobScheduler;
    private final CronJob cronJob;

    public CronService(JobScheduler jobScheduler, CronJob cronJob) {
        this.jobScheduler = jobScheduler;
        this.cronJob = cronJob;
    }

    public void scheduleOneTimeJob() {
        jobScheduler.enqueue(cronJob::executeSampleJob);
    }
}
