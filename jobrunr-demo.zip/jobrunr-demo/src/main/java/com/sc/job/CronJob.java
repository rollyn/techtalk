package com.sc.job;

import org.jobrunr.jobs.annotations.Job;
import org.jobrunr.jobs.annotations.Recurring;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
public class CronJob {

    @Recurring(id = "recurring-job", cron = "${cron.job.expression}")
    @Job(name = "recurring job", retries = 0)
    public void executeSampleJob() throws Exception {
        System.out.println("Running long process!");
        TimeUnit.SECONDS.sleep(1);
        System.out.println("Done");
    }
}
