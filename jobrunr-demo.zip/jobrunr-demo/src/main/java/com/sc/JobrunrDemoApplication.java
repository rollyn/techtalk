package com.sc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobrunrDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobrunrDemoApplication.class, args);
	}

}
