package com.sc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobrunrDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
